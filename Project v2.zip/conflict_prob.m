addpath('./trajectory');
clear history agents belief choke_a arrival 
clear density tot_flight efficiency nearest
clear conflict conflict_number conflict_total
mode=1;
%% sim setting
global dt step
simtime=1500; %simulation length (not time)
dt=1; step=5;
time=0:dt:simtime*dt;

% anum=4; %number of agents
MSD = 3000;
Rlim = 60*10^3;
choke_dest_R = 70*10^3; %4488 nm^2 -> anum 4~10�̸� density: 4.5~22 / 100nm^2
norm_speed=200;

risk=[];
rwy=[];
decisions=[];
belief_diff=zeros(anum,anum); %belief difference
far=ones(anum,anum)*1000000;
compete=ones(1,anum)*1000000;
check = 0;
finished=0; %��ǥ���� ���� agent ��
vel_control=0; %simulation with velocity control ?

%% creating agents / destination / belief
while check == 0
    for i =  1:anum
        choke_a(i) = rand(1)*2*pi;
        choke_R = Rlim*3/5+rand(1)*Rlim*2/5;
%         choke_R = Rlim;
%         choke_R = Rlim-MSD/2+rand(1)*MSD; %�浹�� �� �Ͼ���� ������.
        want = rand(1)*1000;
        want = 0;
        agents(i).pos=[choke_R*cos(choke_a(i)),choke_R*sin(choke_a(i))];  agents(i).hdg=mod(choke_a(i)+pi,2*pi);  ...
%         agents(i).pos=[Rlim*cos(choke_a(i)),Rlim*sin(choke_a(i)   )];  agents(i).hdg=mod(choke_a(i)+pi,2*pi);  ...
            agents(i).vel=norm_speed;  agents(i).req=1000+want; ...
            agents(i).hold=1; agents(i).radius=agents(i).vel*60/pi; agents(i).endflag=0;
    end
    
    % belief hold
%     for i = 1:anum
%         agents(i).req=1000+(i-1)*1000/(anum-1);
%     end
    
    remem=[];
    for j = 1:anum
        for k = 1:anum
            if j ~= k
                remem(j,k)=dist(agents(j).pos(1),agents(j).pos(2),agents(k).pos(1),agents(k).pos(2));
            else
                remem(j,k)=10^6;
            end
        end
    end

    if min(min(remem))<MSD
        check = 0;
    else
        check = 1;
    end
    
end
% agents(anum).req=100;

for i = 1:anum
    DR(i)=agents(i).req;
end %DR generation



%% runway generation
% runway generation - choke
% for i = 1:anum
%     rwy(i).pos=[choke_dest_R*cos(choke_a(i)+pi),choke_dest_R*sin(choke_a(i)+pi)]; rwy(i).hdg=agents(i).hdg;
% end

% runway generation - tot. random
for i = 1:anum
    choke_a(i) = rand(1)*2*pi;
    rwy(i).pos=[choke_dest_R*cos(choke_a(i)),choke_dest_R*sin(choke_a(i))]; 
    vec=rwy(i).pos-agents(i).pos;
    vec_angle=atan2(vec(2),vec(1));
    rwy(i).hdg=vec_angle;
    agents(i).hdg=vec_angle;
end

% runway generation - choke with angle randomness
% for i = 1:anum
%     const=rand(1)*asin(MSD/2/Rlim)*2-asin(MSD/2/Rlim);
%     rwy(i).pos=[choke_dest_R*cos(choke_a(i)+pi+const),choke_dest_R*sin(choke_a(i)+pi+const)];
%     vec=rwy(i).pos-agents(i).pos;
%     vec_angle=atan2(vec(2),vec(1));
%     rwy(i).hdg=vec_angle;
%     agents(i).hdg=vec_angle;
% end

% runway generation - airport landing
% for i = 1:anum
%     rwy(i).pos=[10000,5000]; rwy(i).hdg=pi/2;
% end

for i = 1:anum
    for j = 1:anum
        belief(i,j)=agents(j).req/agents(i).req;
    end
end % belief construction
origin=belief;

if mode == 1
    belief=ones(anum,anum)/1000000;
end
request=0;

%% run
c=0; %finnum
% hold = 1 : ���ϴ� �� ���� ���� (no conflict)
for t=1:simtime
    decision=0;
%% eval others (What are they doing?) - risk eval
    for i = 1:length(agents)
        for j = 1:length(agents)
            if i~=j 
                if agents(j).endflag ~= 1
                    [eta,mindist,type]=riskeval(agents(i),agents(j)); %type => front? back? tie?
                elseif agents(j).endflag == 1
                    eta=1000; mindist=1000; type=0;
                end
                risk{i,j}=[eta,mindist,type];
                if type == 0
                    conflict(i,j) = 0;
                else
                    conflict(i,j) = 1;
                end
            end
        end
    end

%% Where do you want to go? (if no conflict)
    for i = 1:length(agents)
        if agents(i).hold == 1 && agents(i).endflag ~= 1
            los = atan2(rwy(i).pos(2)-agents(i).pos(2),rwy(i).pos(1)-agents(i).pos(1));
            [dth,flag] = anglediff2(los,agents(i).hdg);
            dth=-dth*flag;
            if abs(dth)>6*pi/180
                if dth>0
                    dth=6*pi/180;
                elseif dth<0
                    dth=-6*pi/180;
                end
            end
            decisions{i}=[0,0,1];
        end
    end

%% ������ (Go!) - pos,vel,hdg update
    for i = 1:length(agents)
        if agents(i).endflag == 0
            [agents(i).pos,agents(i).vel,agents(i).hdg]=nextpos2(agents(i),decisions{i}(1),decisions{i}(2));
            if dist(agents(i).pos(1),agents(i).pos(2),rwy(i).pos(1),rwy(i).pos(2)) < 500
                agents(i).endflag = 1;
            end
        end
    end

%% belief update
    
%% record

history{t,1}=t*dt;
history{t,2}=agents;
history{t,3}=risk;
history{t,4}=conflict;

%% termination
c=0;
for i = 1:length(agents)
    if agents(i).endflag==1
        break;
    end
end
for i = 1:anum
    if sum(conflict(i,:)) ~= 0
        at_once(i)=sum(conflict(i,:))+1;
    else
        at_once(i)=0;
    end
end

conflict_number=zeros(1,anum);
for i = 2:anum %���� �浹��
    for j = 1:anum %���� �˻�
        if at_once(j)==i
            conflict_number(i)=conflict_number(i)+1;
        end
    end
end
history{t,5}=conflict_number;
end

%% post process
conflict_total=zeros(1,anum);
for i = 1:t
    for j = 2:anum
        conflict_total(j)=conflict_total(j)+history{i,5}(j);
    end
end
if any(conflict_total) ~= 0
    conflict_total=normalize(conflict_total/simtime,'norm',1)*100;
else
    conflict_total=nan;
end
%% define function
function draw_circle(r,f)
t=0:pi/180:2*pi-pi/180;
if f == 1
    plot(r*cos(t),r*sin(t),'b.')
else
    plot(r*cos(t),r*sin(t),'r:')
end
end

function n=countzero(A)
n=0;
for i = 1:length(A)
    if A(i) == 0
        n=n+1;
    end
end
end

