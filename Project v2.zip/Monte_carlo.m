% mode1: myopic / eta
% mode2: myopic / multi
% mode3: nash / multi
% mode4: nash / eta
% mode5: mode3 + update a=0.01
% mode6: mode3 + updata a= 0.001

clear all
global dt

dt=0.1; %%%%%%%%%%%%%% Ÿ�ӽ��� ����

dispstat('','init');
for modenum = 1:3
    tic
    for anum_t=1:15
        anum=anum_t+1;
        trial = 200;
        mode=modenum;
        datalog=[];
        count=1;
        DRlog=[];
        agility_param = 1;
        for trial_num = 1:trial
%             A=[3000,30,35 500]; B=[210,180,250,3,1,6*pi/180,3*pi/180,0.8]; % for aero
            A=[400 8 8.5 100];  B=[36 0 44.2 4 2 20*pi/180 5*pi/180 0.5]; %for quadrotor designed air taxi
            % A=[5 0.1 0.11 5]; B=[1,0,2,1,0.5,pi/2,pi/4,0]; % for pedestrians
            % A=[10 0.08 0.1 5]; B=[1,0,2,1,0.5,pi/2,pi/4,0.5];
            % A=[100 2 2.2 50]; B=[20,0,40,3,2,0.01,0.01,0.5]; % for train

            [density,tot_flight,nearest,SF,DEP,efficiency,dev_total,DR]=main_MC_dh(A,B,anum,mode);
            if ~isnan(density) && ~isnan(tot_flight)
                datalog(count,:)=[density,tot_flight,nearest,SF,DEP,efficiency,dev_total];
                DRlog(count,:)=DR;
                count=count+1;
            end
            tex=['mode: ',num2str(modenum),...
            ' anum: ',num2str(anum),' processed by: ',num2str(trial_num/trial*100),'%%'];
            dispstat(sprintf(tex));
        end

        if isempty(datalog)
            disp('no data collected')
        else
        alleff=mean(mean(datalog(:,6:6+anum-2)));
        emereff=mean(datalog(:,6+anum-1));
        deveff=mean(mean(datalog(:,6+anum:end-1)));
        devemer=mean(datalog(:,end));
        P=['Density: ',num2str(mean(datalog(:,1))),' Tot_Flhr: ',num2str(mean(datalog(:,2))),' min dist: ',num2str(mean(datalog(:,3))),...
            ' efficiency: ',num2str(alleff)];
        Q=['variance: ',num2str(mean(var(datalog(:,6:6+anum-2)))),' mean eff: ',num2str(emereff),' SF/DEP: ',num2str(mean(datalog(:,4))),' ',num2str(mean(datalog(:,5))),...
            ' yieldness: ',num2str((100-alleff)/(100-emereff))];
        R=['dev_yield; ',num2str(deveff/devemer)];
        disp(P)
        disp(Q)
        disp(R)
        disp(' ')
        dispstat(' ','keepprev')
        end
        saved{modenum,anum_t}=[datalog];
        reluctancy{modenum,anum_t}=DRlog;
    end
    toc
    disp(' ')
    disp(' ')
end
