function [theta]=angleis(xdiff,ydiff)
xdiff=xdiff+exp(-20);
if xdiff>0
    if atan(ydiff/xdiff)>0
        theta=atan(ydiff/xdiff);
    else
        theta=atan(ydiff/xdiff)+2*pi;
    end
elseif xdiff<0
    theta=atan(ydiff/xdiff)+pi;
elseif xdiff==0
    if ydiff>0
        theta=pi/2;
    elseif ydiff<0
        theta=pi/2*3;
    else
        theta=0;
    end        
end
end