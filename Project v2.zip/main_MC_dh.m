function [density,tot_flight,nearest,SF,DEP,efficiency,dev_total,DR]=main_MC_dh(A,B,anum,mode)

%% sim setting
global dt dvlimit dthlimit weight belief_reverse origin buffer
simtime = 15000; %simulation length (not time)


MSD = A(1);
Rlim = A(2)*10^3;
choke_dest_R = A(3)*10^3; %4488 nm^2 -> anum 4~10�̸� density: 4.5~22 / 100nm^2e

norm_speed=B(1); minspeed=B(2); maxspeed=B(3); %plane

rwy=[];
far=ones(anum,anum)*1000000;
check = 0;
finished=0; %��ǥ���� ���� agent ��

dvlimit=B(4); dvrecover=B(5); dthlimit=B(6); dthrecover=B(7);
weight=B(8); % near 1, less vel control & more th control
buffer = A(4);

%% creating agents / destination / belief
while check == 0
    for i =  1:anum
        choke_a(i) = rand(1)*2*pi;
%         choke_R = Rlim*3/5+rand(1)*Rlim*2/5;
%         choke_R = Rlim;
        choke_R = Rlim-MSD/2+rand(1)*MSD; %�浹�� �� �Ͼ���� ������.
        want = rand(1)*1000;
        agents(i).pos=[choke_R*cos(choke_a(i)),choke_R*sin(choke_a(i))];  agents(i).hdg=mod(choke_a(i)+pi,2*pi);  ...
%         agents(i).pos=[Rlim*cos(choke_a(i)),Rlim*sin(choke_a(i)   )];  agents(i).hdg=mod(choke_a(i)+pi,2*pi);  ...
            agents(i).vel=norm_speed;  agents(i).req=1000+want; ...
            agents(i).hold=1; agents(i).radius=agents(i).vel*60/pi; agents(i).endflag=0;
    end
    
    % belief hold
%     for i = 1:anum
%         agents(i).req=1000+(i-1)*1000/(anum-1);
%     end
    
    remem=[];
    for j = 1:anum
        for k = 1:anum
            if j ~= k
                remem(j,k)=dist(agents(j).pos(1),agents(j).pos(2),agents(k).pos(1),agents(k).pos(2));
            else
                remem(j,k)=10^6;
            end
        end
    end

    if min(min(remem))<MSD
        check = 0;
    else
        check = 1;
    end
    
end

% agents(anum).req=100;  %%%%%%%%%%%%%% ���� ���� ����

for i = 1:anum
    DR(i)=agents(i).req;
end %DR generation



%% runway generation
% runway generation - choke
% for i = 1:anum
%     rwy(i).pos=[choke_dest_R*cos(choke_a(i)+pi),choke_dest_R*sin(choke_a(i)+pi)]; rwy(i).hdg=agents(i).hdg;
% end

% runway generation - tot. random
% for i = 1:anum
%     choke_a(i) = rand(1)*2*pi;
%     rwy(i).pos=[choke_dest_R*cos(choke_a(i)),choke_dest_R*sin(choke_a(i))]; 
%     vec=rwy(i).pos-agents(i).pos;
%     vec_angle=atan2(vec(2),vec(1));
%     rwy(i).hdg=vec_angle;
%     agents(i).hdg=vec_angle;
% end

% runway generation - choke with angle randomness
for i = 1:anum
    const=rand(1)*asin(MSD/2/Rlim)*2-asin(MSD/2/Rlim);
    rwy(i).pos=[choke_dest_R*cos(choke_a(i)+pi+const),choke_dest_R*sin(choke_a(i)+pi+const)];
    vec=rwy(i).pos-agents(i).pos;
    vec_angle=atan2(vec(2),vec(1));
    rwy(i).hdg=vec_angle;
    agents(i).hdg=vec_angle;
end

% runway generation - airport landing
% for i = 1:anum
%     rwy(i).pos=[10000,5000]; rwy(i).hdg=pi/2;
% end

for i = 1:anum
    for j = 1:anum
        belief(i,j)=agents(j).req/agents(i).req;
    end
end % belief construction
origin=belief;

if mode == 1 || mode == 2
%     belief=ones(anum,anum)/1000000;
belief = ones(anum,anum);
end
belief_reverse=belief';
request=0;
S1=no_comp(agents,rwy,MSD);
c=0; %finnum


%% Main run
for t=1:simtime
    [agents,output]=sim_step_execute(agents,rwy,belief,A,B,mode,anum,finished,far);

    history{t,1}=t*dt;
    history{t,2}=output{2};
    history{t,3}=output{3};
    history{t,4}=output{4};
    history{t,5}=output{5};
    history{t,6}=output{6};
    c=0;
    for i = 1:length(agents)
        if agents(i).endflag==1
            c=c+1;
        end
    end
    if c==length(agents)
        simtime=t;
        break;
    end
    finished=c;
end

%% post process
flag=zeros(1,length(agents));
for i = 1:length(agents)
    for j = 1:length(history)
        n=history{j,2}(i).endflag;
        if n==1 && flag(i)==0
            arrival(i)=j;
            flag(i)=1;
        end
        hdg_profile(i,j)=history{j,2}(i).hdg;
        vel_profile(i,j)=history{j,2}(i).vel;
        comm_profile(i,j)=history{j,4}{i}(1);
    end
end

for i = 1:length(agents)
    if flag(i)==0
        arrival(i)=nan;
    end
    temp=0;
    for j = 1:length(history)
        temp=temp+history{j,2}(i).vel;
    end
    tot_distance(i)=temp;
end
% recording all distances between agents
remem=[];
if ~isnan(arrival)
for i = 1:min(arrival)-1
    for j = 1:anum
        for k = 1:anum
            if j ~= k
                remem(i,j,k)=history{i,5}(j,k);
            else
                remem(i,j,k)=10000;
            end
        end
    end
end
end

% data processing
nearest = min(min(min(remem)));
tot_flight = sum(arrival);
density = sum(arrival)/simtime/(pi*(choke_dest_R/1000)^2)*24*365;

% recording all decisions
remem=[];
for i = 1:anum
    for t = 1:simtime
%         remem(t) = abs(history{t,4}{i}(1)/dthlimit) + abs(history{t,4}{i}(2)/dvlimit);
        remem(t) = (history{t,4}{i}(1)/dthlimit)^2 + (history{t,4}{i}(2)/dvlimit)^2;
    end
%     dev_total(i)=sum(remem);
    dev_total(i)=sum(sqrt(remem));
end
dev_total = dev_total./arrival*100;

% calculate efficiency
for i = 1:anum
%     efficiency(i)=(dist(history{1,2}(i).pos(1),history{1,2}(i).pos(2),rwy(i).pos(1),rwy(i).pos(2))-buffer)/history{1,2}(i).vel/arrival(i)*100;
%     efficiency(i)=(dist(history{1,2}(i).pos(1),history{1,2}(i).pos(2),rwy(i).pos(1),rwy(i).pos(2))-buffer)/tot_distance(i)*100;
    efficiency(i)=dev_total(i);
end

S2=0;
for i = 1:t
    for j = 1:length(agents)
        if history{i,2}(j).hold==0
%         if history{i,6}(j,:)>MSD
            S2=S2;
        else
            S2=S2+1;
        end
    end
end
if S1 == 0
    S1 = 1;
end
if S2 == 0
    S2=S1;
end
SF = S1/S2;
DEP = 1/SF-1;

end
