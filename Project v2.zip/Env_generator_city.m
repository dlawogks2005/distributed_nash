clear all
close all
addpath('./trajectory'); 
mode = 3;
%% sim setting
global dt dvlimit dthlimit weight buffer alert_t agents rwy
global au s_num s_dist s_pos s_dir A B norm_speed anum MSD mode

% % [MSD max_r min_r buffer] [nomv minv maxv maxacc nomacc maxdth nomdth w]
% A=[3000 30 35 500]; B=[210,180,250,3,1,6*pi/180,3*pi/180,0.5]; % for aero
% A=[400 2 2.3 200];  B=[30 0 44.2 4 2 20*pi/180 5*pi/180 0.5]; alert_t = 30; %for quadrotor designed air taxi
A=[5 0.05 0.055 5]; B=[1,0,2,1,0.5,pi/2,pi/8,0.5]; alert_t = 10; % for pedestrians
% A=[300 2 2.2 50]; B=[20,0,40,3,2,0.01,0.01,0.5]; % for train

simtime=9000; %simulation length (not time)
dt=0.1; 
time=0:dt:simtime*dt;

anum=5; %number of agents
MSD = A(1);
Rlim = A(2)*10^3;
choke_dest_R = A(3)*10^3; %4488 nm^2 -> anum 4~10�̸� density: 4.5~22 / 100nm^2
norm_speed=B(1); minspeed=B(2); maxspeed=B(3);

risk=[];
rwy=[];
decisions=[];
far=ones(anum,anum)*1000000;
compete=ones(1,anum)*1000000;
check = 0;
finished=0; %��ǥ���� ���� agent ��

dvlimit=B(4); dvrecover=B(5);  dthlimit=B(6); dthrecover=B(7); weight=B(8);
buffer = A(4);

%% station setting
au = pi/4;
s_num = 4;
s_dist = 10;
s_pos = [0 0;MSD*s_dist*2 0;0 MSD*s_dist;MSD*s_dist*1.3 MSD*s_dist*1.8];
s_dir = [au,au*3,au*7,au*5];
s_a_record = []; % ��� ���� '�����'�� �����ƴ��� ���
%% map generation / agent generation

while check == 0
    for i =  1:anum
        s_idx = randperm(s_num,1);
        choke_R = rand(1)*MSD*2;
        choke_a = s_dir(s_idx) + rand(1)*pi/2 -pi/4;
        s_a_record(i,1) = s_idx;
        want = rand(1)*100;

        agents(i).pos=[rand(1)*max(s_pos(:,1)),rand(1)*max(s_pos(:,2))];
        agents(i).hdg=mod(choke_a,2*pi);
        agents(i).vel=norm_speed;
        agents(i).req=1000+want;
        agents(i).hold=1; 
        agents(i).endflag=0;
    end
    agents_initial=agents;
   
    remem=[];
    for j = 1:anum
        for k = 1:anum
            if j ~= k
                remem(j,k)=dist(agents(j).pos(1),agents(j).pos(2),agents(k).pos(1),agents(k).pos(2));
            else
                remem(j,k)=10^6;
            end
        end
    end

    if min(min(remem))<MSD
        check = 0;
    else
        check = 1;
    end

end
% agents(anum).req=10;

for i = 1:anum
    DR(i)=agents(i).req;
end

% runway generation
for i = 1:anum
    s_idx = randperm(s_num,1);
    while s_a_record(i) == s_idx
        s_idx = randperm(s_num,1);
    end
    s_a_record(i,2) = s_idx;
    choke_R = rand(1)*MSD;
    choke_a = s_dir(s_idx) + rand(1)*pi - pi/2;
    
    rwy(i).pos=[s_pos(s_idx,1)+choke_R*cos(choke_a),s_pos(s_idx,2)+choke_R*sin(choke_a)];
    vec=rwy(i).pos-agents(i).pos;
    vec_angle=atan2(vec(2),vec(1));
    rwy(i).hdg=vec_angle;
end


for i = 1:anum
    for j = 1:anum
        belief(i,j)=agents(j).req/agents(i).req;
    end
end % belief construction
origin=belief;

if mode == 1 || mode == 2
    belief=ones(anum,anum);
end
belief_reverse=belief';
request=0;
S1=no_comp(agents,rwy,MSD);
c=0; %finnum

clear f
save('Environment')

