function [fpos,fvel,fhdg,hld,endflag]=proceed_obs(a,dv)
global step dt
v=a.vel; path=a.traj.path; it=a.hold; endflag=a.endflag;
v=v+dv;
n=1+it*v/step*dt;
if n>length(path)
    endflag=1;
end

if endflag==1
    fpos=[a.pos(1),a.pos(1)];
    fvel=0;
    fhdg=0;
    hld=1;
else
    fposx=path(n,1);
    fposy=path(n,2);
    fpos=[fposx,fposy];
    fvel=v;
    fhdg=path(n,4);
    hld=it+1;
end


end