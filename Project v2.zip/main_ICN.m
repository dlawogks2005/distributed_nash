clear all
close all
addpath('./trajectory');

%% Hello world!
ICN=imread('ICN.png');
pixel_pos=[332,292
415,326
620,179
509,477
576,576  %499
677,612
775,702
309,223];
pixel_pos=pixel_pos/16.5*1000; %to m base
pixel_pos=round(pixel_pos);
global dt step
anum=7; %number of agents
simtime=700; %simulation length (not time)
dt=1; step=5;
time=0:dt:simtime*dt;

risk=[];

belief_diff=zeros(anum,anum); %belief difference
decisions=[];
far=ones(anum,anum)*1000000;
compete=ones(1,anum)*1000000;

a1.pos=[pixel_pos(1,1),pixel_pos(1,2)];  a1.hdg=mod(hdg(220),2*pi);  a1.vel=90;  a1.req=2000; a1.hold=0; a1.radius=a1.vel*60/pi; a1.endflag=0;
a2.pos=[pixel_pos(2,1),pixel_pos(2,2)];  a2.hdg=mod(hdg(210),2*pi);  a2.vel=90;  a2.req=2000; a2.hold=0; a2.radius=a2.vel*60/pi; a2.endflag=0;
a3.pos=[pixel_pos(3,1),pixel_pos(3,2)];  a3.hdg=mod(hdg(290),2*pi);  a3.vel=90;  a3.req=2000; a3.hold=0; a3.radius=a3.vel*60/pi; a3.endflag=0;
a4.pos=[pixel_pos(4,1),pixel_pos(4,2)];  a4.hdg=mod(hdg(230),2*pi);  a4.vel=90;  a4.req=500; a4.hold=0; a4.radius=a4.vel*60/pi; a4.endflag=0;
a5.pos=[pixel_pos(5,1),pixel_pos(5,2)];  a5.hdg=mod(hdg(200),2*pi);  a5.vel=90;  a5.req=2000; a5.hold=0; a5.radius=a5.vel*60/pi; a5.endflag=0;
a6.pos=[pixel_pos(6,1),pixel_pos(6,2)];  a6.hdg=mod(hdg(260),2*pi);  a6.vel=90;  a6.req=2000; a6.hold=0; a6.radius=a6.vel*60/pi; a6.endflag=0;
a7.pos=[pixel_pos(7,1),pixel_pos(7,2)];  a7.hdg=mod(hdg(270),2*pi);  a7.vel=90;  a7.req=2000; a7.hold=0; a7.radius=a7.vel*60/pi; a7.endflag=0;

agents=[a1,a2,a3,a4,a5,a6,a7];

temp=[1/a1.req,1/a2.req,1/a3.req,1/a4.req,1/a5.req,1/a6.req,1/a7.req]'.*ones(anum,anum);
belief=[a1.req;a2.req;a3.req;a4.req;a5.req;a6.req;a7.req]'.*temp;

% belief=belief'; % wrong belief
% belief=ones(anum,anum);
% belief=belief.^5;

rwy.pos=[pixel_pos(8,1),pixel_pos(8,2)]; rwy.hdg=hdg(220);
clear a1 a2 a3 a4 a5 a6 a7 a8 temp

for t=1:simtime
    decision=0;
%% generate path (Your intention is?)
    for i = 1:length(agents)
        if agents(i).hold == 0
            [path, length_All, length_LR_SEG, type] = dubins_curve_v2([agents(i).pos,agents(i).hdg], ...
                [rwy.pos,rwy.hdg], agents(i).radius, step, 0, 0); %radius, step, ~, ~
            agents(i).traj.path=path;
            agents(i).traj.len=length_All;
            agents(i).traj.LRlen=length_LR_SEG;
            agents(i).traj.type=type;
        end
    end

%% eval others (What are they doing?) - risk eval
    for i = 1:length(agents)
        for j = 1:length(agents)
            if i~=j
                [eta,mindist,type]=riskeval(agents(i),agents(j)); %type => front? back? tie?
                risk{i,j}=[eta,mindist,type];
            end
        end
    end

%% decision (Your reaction is?) - decision making
% for i = 1:length(agents)
%     for j = 1:length(agents)
%         if i~=j
%             far(i,j)=dist(agents(i).pos(1),agents(i).pos(2),agents(j).pos(1),agents(j).pos(2));
%         end
%     end
%     [~,num]=min(far(i,:));
%     compete(i)=num;
% end
for i = 1:length(agents)
    temp=[];
    norm=[];
    n=1;
    for j = 1:length(agents)
        if j ~= i
            num=j;
            [dth,dv,go]=decide_direction(agents(i),agents(num),risk{i,num}(1),risk{i,num}(2),risk{i,num}(3),agents(i).req,belief(i,num));
            temp(n,:)=[dth,dv,go];
            n=n+1;
        end
    end
    
    
    for k = 1:length(agents)
        m=1;
        for j = 1:length(agents)
            if k ~= j
                tempbelief(k,m)=belief(j,k);
                m=m+1;
            end
        end
    end
    norm=tempbelief(i,:);
    norm=norm/sum(norm); %normalize belief
    temp;
    dth=norm*temp(:,1);
    dv=norm*temp(:,2);
    if dv<0
        dv=-5;
    elseif dv>0
        dv=5;
    else
        dv=0;
    end
    if temp(:,3)~=0 %��� 0�� �ƴϾ�� �����.
        go=go;
    else            %�ϳ��� 0�̸� go�� 0
        go=0;
    end
    decisions{i}=[dth,dv,go];
    agents(i).hold=go;
end

%% ������ (Go!) - pos,vel,hdg update
    for i = 1:length(agents)
        if agents(i).hold~=0
            [agents(i).pos,agents(i).vel,agents(i).hdg,agents(i).hold,agents(i).endflag]=proceed(agents(i),decisions{i}(2));
        elseif agents(i).hold==0
            [agents(i).pos,agents(i).vel,agents(i).hdg,agents(i).hold]=nextpos(agents(i),decisions{i}(1),decisions{i}(2));
        end
    end

%% record
far=[];
for i = 1:length(agents)
    for j = 1:length(agents)
        if i~=j
            far(i,j)=dist(agents(i).pos(1),agents(i).pos(2),agents(j).pos(1),agents(j).pos(2));
        end
    end
end
history{t,1}=t*dt;
history{t,2}=agents;
history{t,3}=risk;
history{t,4}=decisions;
history{t,5}=far;

%% termination
c=0;
for i = 1:length(agents)
    if agents(i).endflag==1
        c=c+1;
    end
end
if c==length(agents)
    simtime=t;
    break;
end
end

%% post process
flag=zeros(1,anum);

for i = 1:length(agents)
    for j = 1:length(history)
        n=history{j,2}(i).vel;
        if n<10 && flag(i)==0
            arrival(i)=j;
            flag(i)=1;
        end
        hdg_profile(i,j)=history{j,2}(i).hdg;
        vel_profile(i,j)=history{j,2}(i).vel;
        comm_profile(i,j)=history{j,4}{i}(1);
    end
end

for i = 1:length(agents)
    if flag(i)==0
        arrival(i)=nan;
    end
end

%% visualization
factor=16.5/1000;

wordp=['total simulation time: ',num2str(t),'sec'];
word1=['a1 arrival time: ',num2str(arrival(1)),'sec'];
word2=['a2 arrival time: ',num2str(arrival(2)),'sec'];
word3=['a3 arrival time: ',num2str(arrival(3)),'sec'];
word4=['a4 arrival time: ',num2str(arrival(4)),'sec'];
word5=['a5 arrival time: ',num2str(arrival(5)),'sec'];
word6=['a6 arrival time: ',num2str(arrival(6)),'sec'];
word7=['a7 arrival time: ',num2str(arrival(7)),'sec'];

disp(wordp)
disp(word1)
disp(word2)
disp(word3)
disp(word4)
disp(word5)
disp(word6)
disp(word7)

figure(1)
imshow(ICN)
hold on
grid on
title('trajectory profile','fontsize',14)
xlabel('x position[m]','fontsize',14)
ylabel('y position[m]','fontsize',14)
plot(round([rwy.pos(1)*factor,(rwy.pos(1)+round(3000*cos(rwy.hdg)))*factor]),round([rwy.pos(2)*factor,factor*(rwy.pos(2)+round(3000*sin(rwy.hdg)))]),'g','LineWidth',5)
txt1 = ' \leftarrow RWY32 approach fix';
text(round(rwy.pos(1)*factor),round((rwy.pos(1)+round(3000*cos(rwy.hdg)))*factor-57),txt1,'HorizontalAlignment','left');

% figure(2)
% f=figure(2);
% hold on
% grid on
% plot(time(1:simtime),hdg_profile(1,:)*180/pi,'b:')
% plot(time(1:simtime),hdg_profile(2,:)*180/pi,'r:')
% plot(time(1:simtime),hdg_profile(3,:)*180/pi,'k:')
% plot(time(1:simtime),hdg_profile(4,:)*180/pi,'m:')
% plot(time(1:simtime),hdg_profile(5,:)*180/pi,'b:')
% plot(time(1:simtime),hdg_profile(6,:)*180/pi,'r:')
% plot(time(1:simtime),hdg_profile(6,:)*180/pi,'k:')
% xlim([0 time(simtime)])
% ylim([0 360])
% set(f,'position',[-1450,700,1400,300])
% title('heading','fontsize',15)
% xlabel('simulation time [s]','fontsize',14)
% ylabel('heading [deg]','fontsize',14)
% 
% figure(3)
% f=figure(3);
% hold on
% grid on
% plot(time(1:simtime),comm_profile(1,:)*180/pi,'b:')
% plot(time(1:simtime),comm_profile(2,:)*180/pi,'r:')
% plot(time(1:simtime),comm_profile(3,:)*180/pi,'k:')
% plot(time(1:simtime),comm_profile(4,:)*180/pi,'m:')
% plot(time(1:simtime),comm_profile(5,:)*180/pi,'b:')
% plot(time(1:simtime),comm_profile(6,:)*180/pi,'r:')
% plot(time(1:simtime),comm_profile(7,:)*180/pi,'k:')
% xlim([0 time(simtime)])
% ylim([-7 7])
% set(f,'position',[-1450,350,1400,300])
% title('turn command','fontsize',15)
% xlabel('simulation time [s]','fontsize',14)
% ylabel('turn command [deg/s]','fontsize',14)
% 
% figure(4)
% f=figure(4);
% hold on
% grid on
% plot(time(1:simtime),vel_profile(1,:),'b:')
% plot(time(1:simtime),vel_profile(2,:),'r:')
% plot(time(1:simtime),vel_profile(3,:),'k:')
% plot(time(1:simtime),vel_profile(4,:),'m:')
% plot(time(1:simtime),vel_profile(5,:),'b:')
% plot(time(1:simtime),vel_profile(6,:),'r:')
% plot(time(1:simtime),vel_profile(7,:),'k:')
% xlim([0 time(simtime)])
% ylim([75 105])
% set(f,'position',[-1450,0,1400,300])
% title('velocity profile','fontsize',15)
% xlabel('simulation time [s]','fontsize',14)
% ylabel('velocity [m/s]','fontsize',14)

for i = 1:simtime
%     figure(1)
%     plot(history{i,2}(1).pos(1),history{i,2}(1).pos(2),'bx')
%     plot(history{i,2}(2).pos(1),history{i,2}(2).pos(2),'rx')
%     plot(history{i,2}(3).pos(1),history{i,2}(3).pos(2),'kx')
%     plot(history{i,2}(4).pos(1),history{i,2}(4).pos(2),'mx')
%     plot(history{i,2}(5).pos(1),history{i,2}(5).pos(2),'bx')
%     plot(history{i,2}(6).pos(1),history{i,2}(6).pos(2),'rx')
%     plot(history{i,2}(7).pos(1),history{i,2}(7).pos(2),'kx')
    
    p1=plot(round(history{i,2}(1).traj.path(:,1)*factor),round(history{i,2}(1).traj.path(:,2)*factor),'b:');
    p2=plot(round(history{i,2}(2).traj.path(:,1)*factor),round(history{i,2}(2).traj.path(:,2)*factor),'r:');
    p3=plot(round(history{i,2}(3).traj.path(:,1)*factor),round(history{i,2}(3).traj.path(:,2)*factor),'k:');
    p4=plot(round(history{i,2}(4).traj.path(:,1)*factor),round(history{i,2}(4).traj.path(:,2)*factor),'m:');
    p5=plot(round(history{i,2}(5).traj.path(:,1)*factor),round(history{i,2}(5).traj.path(:,2)*factor),'b:');
    p6=plot(round(history{i,2}(6).traj.path(:,1)*factor),round(history{i,2}(6).traj.path(:,2)*factor),'r:');
    p7=plot(round(history{i,2}(7).traj.path(:,1)*factor),round(history{i,2}(7).traj.path(:,2)*factor),'k:');
    
    plot(round(history{i,2}(1).pos(1)*factor),round(history{i,2}(1).pos(2)*factor),'b.')
    plot(round(history{i,2}(2).pos(1)*factor),round(history{i,2}(2).pos(2)*factor),'r.')
    plot(round(history{i,2}(3).pos(1)*factor),round(history{i,2}(3).pos(2)*factor),'k.')
    plot(round(history{i,2}(4).pos(1)*factor),round(history{i,2}(4).pos(2)*factor),'m.')
    plot(round(history{i,2}(5).pos(1)*factor),round(history{i,2}(5).pos(2)*factor),'b.')
    plot(round(history{i,2}(6).pos(1)*factor),round(history{i,2}(6).pos(2)*factor),'r.')
    plot(round(history{i,2}(7).pos(1)*factor),round(history{i,2}(7).pos(2)*factor),'k.')
    
%     figure(2)
%     plot(time(i),hdg_profile(1,i)*180/pi,'b.')
%     plot(time(i),hdg_profile(2,i)*180/pi,'r.')
%     plot(time(i),hdg_profile(3,i)*180/pi,'k.')
%     plot(time(i),hdg_profile(4,i)*180/pi,'m.')
%     plot(time(i),hdg_profile(5,i)*180/pi,'b.')
%     plot(time(i),hdg_profile(6,i)*180/pi,'r.')
%     plot(time(i),hdg_profile(7,i)*180/pi,'k.')
% 
%     figure(3)
%     plot(time(i),comm_profile(1,i)*180/pi,'b.')
%     plot(time(i),comm_profile(2,i)*180/pi,'r.')
%     plot(time(i),comm_profile(3,i)*180/pi,'k.')
%     plot(time(i),comm_profile(4,i)*180/pi,'m.')
%     plot(time(i),comm_profile(5,i)*180/pi,'b.')
%     plot(time(i),comm_profile(6,i)*180/pi,'r.')
%     plot(time(i),comm_profile(7,i)*180/pi,'k.')
%     
%     figure(4)
%     plot(time(i),vel_profile(1,i),'b.')
%     plot(time(i),vel_profile(2,i),'r.')
%     plot(time(i),vel_profile(3,i),'k.')
%     plot(time(i),vel_profile(4,i),'m.')
%     plot(time(i),vel_profile(5,i),'b.')
%     plot(time(i),vel_profile(6,i),'r.')
%     plot(time(i),vel_profile(7,i),'k.')
%     pause(1)
    figure(1)
    set(p1,'Visible','off')
    set(p2,'Visible','off')
    set(p3,'Visible','off')
    set(p4,'Visible','off')
    set(p5,'Visible','off')
    set(p6,'Visible','off')
    set(p7,'Visible','off')
    
    
end
figure(2)
for i = 1:simtime
plot(i,history{i,5}(3,4),'k.')
hold on
end
figure(1)
legend('runway','agent1','agent2')


