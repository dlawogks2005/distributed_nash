function figout=draw_circle(r,f,c)

t=0:pi/180:2*pi-pi/180;
if f == 1
    figout=plot(r*cos(t)+c(1),r*sin(t)+c(2),'b.');
elseif f == 2
    figout=plot(r*cos(t)+c(1),r*sin(t)+c(2),'r:');
else
    figout=plot(r*cos(t)+c(1),r*sin(t)+c(2),'r');
end

end