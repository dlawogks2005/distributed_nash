function [hold]=decide_direction_nocomp(a,b,eta,mindist,type,req_dist)
pos1=a.pos; h1=a.hdg;
pos2=b.pos; h2=b.hdg;

y1=pos1(2); y2=pos2(2);
x1=pos1(1); x2=pos2(1);

xdiff=x2-x1;
ydiff=y2-y1;
theta=angleis(xdiff,ydiff);
flag=anglerel_mod(h1,theta);
flag2=anglerel_mod(h1,h2);
dist=sqrt(xdiff^2+ydiff^2);
reqdist=req_dist;

if  eta>0 && eta<60 && mindist<reqdist || dist<reqdist
    if type == 0
        if a.hold==0
            a.hold=1;
        end
        hold=a.hold;

    elseif type == 2
        hold=0;
        
    elseif type == 1
        hold=0;

    else % ������ �а� �Ұ� type = 3 or type = 4
        if reqdist-mindist <= 0
            hold=a.hold;
            if a.hold==0
                hold=1;
            end
        else
            hold=0;
        end
    end

else %no conflict
    dth=0;
    hold=a.hold;
    if a.hold==0
        hold=1;
    end
end

end