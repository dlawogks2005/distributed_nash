function l = dist(x,y,x2,y2)
xdiff=x2-x;
ydiff=y2-y;
l=sqrt(xdiff^2+ydiff^2);
end