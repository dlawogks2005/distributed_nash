function [dth,dv]=d_portion(dth_max,dv_max,dthlim,dvlim,w)
slope = -dth_max/dv_max;
edge = [dv_max,dth_max];
x=[0;0];

% %����ؼ� ����� �Ʊ��. ���ܵΰ���.
if dth_max>0 && dv_max>0
    if dth_max>dthlim
        dth_point=dthlim;
    else
        dth_point=dth_max;
    end

    if dv_max>dvlim
        dv_point=dvlim;
    else
        dv_point=dv_max;
    end

    sol(1,:)=[dv_point,slope*dv_point+dth_max];
    sol(2,:)=[(dth_point-dth_max)/slope,dth_point];

    for i = 1:2
        if sol(i,:) > edge
            sol(i,:)=edge;
        end
    end

    cost(1)=w*sol(1,2)/dth_max+(1-w)*sol(1,1)/dv_max;
    cost(2)=w*sol(2,2)/dth_max+(1-w)*sol(2,1)/dv_max;

    [~,index]=min(cost);

    dth=sol(index,2);
    dv=sol(index,1);
else
    dth=dth_max;
    dv=dv_max;
end

%% LP
% f=[w/dth_max (1-w)/dv_max];
% A=[1,0;0,1];
% b=[dthlim;dvlim];
% Aeq=[1,-slope];
% beq=[dth_max];
% lb=[0,0];
% ub=[dthlim,dvlim];
% x = linprog(f,A,b,Aeq,beq,lb,ub);
% dth=x(1); dv=x(2);

%% convex problem
% if dth_max>0 && dv_max>0
%     options = optimoptions('fmincon','Display','off');
%     J = @(x) w*(x(1)/dthlim*100)^2 + (1-w)*(x(2)/dvlim*100)^2;
%     % J = @(x) w*(x(1)/dthlim) + (1-w)*(x(2)/dvlim);
%     x = fmincon(J,[0,0],[1,0;0,1],[dthlim;dvlim],[-slope,1],dth_max,[0,0],[dthlim,dvlim],[],options);
% 
%     dth=x(1); dv=x(2);
% else
%     dth=dth_max;
%     dv=dv_max;
% end

end