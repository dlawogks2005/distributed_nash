function agents = agent_regen(num)
% num : ���� ��� ������Ʈ�� ��ȣ
%% station setting
global au s_num s_dist s_pos s_dir mode rwy MSD agents
global dt dvlimit dthlimit weight buffer alert_t norm_speed anum

%% map generation / agent generation
check=0;
iteration = 1;
while check == 0
    s_idx = randperm(s_num,1);
    choke_R = rand(1)*MSD*3;
    choke_a = s_dir(s_idx) + rand(1)*pi -pi/2;
    s_a_record = s_idx;
    want = rand(1)*100;
    agents(num).pos=[s_pos(s_idx,1)+choke_R*cos(choke_a),s_pos(s_idx,2)+choke_R*sin(choke_a)];
    agents(num).hdg=mod(choke_a,2*pi);
    agents(num).vel=norm_speed;  
    agents(num).req=1000+want;
    agents(num).hold=1; 
    agents(num).endflag=0;
    remem=[];
    
    for j = 1:anum
        for k = 1:anum
            if j ~= k
                remem(j,k)=dist(agents(j).pos(1),agents(j).pos(2),agents(k).pos(1),agents(k).pos(2));
            else
                remem(j,k)=10^6;
            end
        end
    end

    if min(min(remem))<MSD
        check = 0;
    else
        check = 1;
    end
    iteration = iteration + 1;
    if iteration > 100
        agents(num).pos=[rand(1)*max(s_pos(:,1)),rand(1)*max(s_pos(:,2))];
        agents(num).hdg=mod(choke_a,2*pi);
        agents(num).vel=norm_speed;
        agents(num).req=1000+want;
        agents(num).hold=1; 
        agents(num).endflag=0;
        break;
    end
end
if num == anum
    agents(num).req = 10;
end
% runway generation
s_idx = randperm(s_num,1);
while s_a_record == s_idx
    s_idx = randperm(s_num,1);
end

choke_R = rand(1)*MSD;
choke_a = s_dir(s_idx) + rand(1)*pi - pi/2;

rwy(num).pos=[s_pos(s_idx,1)+choke_R*cos(choke_a),s_pos(s_idx,2)+choke_R*sin(choke_a)];
vec=rwy(num).pos-agents(num).pos;
vec_angle=atan2(vec(2),vec(1));
rwy(num).hdg=vec_angle;

for i = 1:anum
    for j = 1:anum
        belief(i,j)=agents(j).req/agents(i).req;
    end
end % belief construction

if mode == 1 || mode == 2
    belief=ones(anum,anum);
end
end