function [agents,record]=sim_step_execute(agents,rwy,belief,A,B,mode,anum,finished,far)
global buffer origin dt
MSD = A(1);
norm_speed=B(1); minspeed=B(2); maxspeed=B(3);
dvlimit=B(4); dvrecover=B(5); dthlimit=B(6); dthrecover=B(7);
weight=B(8);
%% eval others (What are they doing?) - risk eval
    for i = 1:length(agents)
        for j = 1:length(agents)
            if i~=j 
                if agents(j).endflag ~= 1
                    [eta,mindist,type]=riskeval(agents(i),agents(j)); %type => front? back? tie?
                elseif agents(j).endflag == 1
                    eta=1000; mindist=1000; type=0;
                end
                risk{i,j}=[eta,mindist,type];
            end
        end
    end
    
%% decision making - if conflict = TRUE
    % Myopic algorithm
    if mode == 1 || mode == 4
        for i = 1:length(agents)
    %     ���� ��� - ����� �� ����, eta �������
        temp=ones(1,anum)*10^20;
        n=1;
        for j = 1:anum
            if i~=j
                temp(n)=risk{i,j}(1); %eta
            end
            n=n+1;
        end
        [~,num]=min(temp);
        [dth,dv,go]=decide_direction2(agents(i),agents(num),risk{i,num}(1),risk{i,num}(2),risk{i,num}(3),MSD,belief(i,num)); 

        if go == 1
            temp=ones(1,anum)*10^20;
            n=1;
            for j = 1:anum
                if i~=j
                    temp(n)=far(i,j);
                end
                n=n+1;
            end
            [~,num]=min(temp);
            [dth,dv,go]=decide_direction2(agents(i),agents(num),risk{i,num}(1),risk{i,num}(2),risk{i,num}(3),MSD,belief(i,num));
            agents(i).hold=go;
        end
        
        [dth,dv]=d_portion(dth,dv,dthlimit,dvlimit,weight);
        decisions{i}=[dth,dv,go];
        agents(i).hold = go;

%         decisions{i}=[dth,0,go];
%         agents(i).hold=go;
        end %eta / myopic
    
    % Nash algorithm
    elseif mode == 2 || mode == 3
        for i = 1:length(agents) %% i = idx of ownship
            temp=[];
            n=1;
            for j = 1:length(agents) %% j = idx of opponent
                if j ~= i && agents(j).endflag == 0 %% when opponent's active
                    num=j;
                    [dth,dv,go]=decide_direction2(agents(i),agents(num),risk{i,num}(1),risk{i,num}(2),risk{i,num}(3),MSD,belief(i,num));
                    temp(n,:)=[dth,dv,go]; %% aloc-
                    idx_temp(n)=j; %% to know aloc- is from conflict with whom
                    n=n+1;
                end
            end % why use n? : alive agents num may vary
            
            % aloc- process
            if anum-finished ~= 1 % if i am 'not' the only one active
                zeronum = countzero(temp(:,3)); 
                zeronum = n - zeronum; % number of non-conflicts
                if zeronum == anum-1-finished % if nobody is under conflict
                    dth=0; dv=0;
                else % if anyone is under conflict -> f-process
                    temp_sum=0;
                    for j = 1:length(idx_temp)
                        temp_sum=temp_sum+belief(i,idx_temp(j));
                    end
                    norm=[];
                    for normnum = 1:size(temp,1)
                        norm(normnum)=(1+belief(1,idx_temp(normnum)))/(1+temp_sum);
                    end
                    dth=norm*temp(:,1);
                    dv=norm*temp(:,2);
                end
            else % if i'm the only one active
                dth=0; dv=0;
            end
            
            % truncation error bye-bye
            if abs(dth)>1*10^(-5) || abs(dv)>1*10^(-5)
                go=0;
            else
                go=1;
            end
            
            decisions{i}=[dth,dv,go];
            agents(i).hold=go;

            if agents(i).endflag == 1 % agent inactivation
                agents(i).hold = 0;
            end

            % f- process (method selection)
            [dth_temp,dv_temp]=d_portion(dth,dv,dthlimit,dvlimit,weight);
            decisions{i}(1)=dth_temp; decisions{i}(2)=dv_temp;

            
%             decisions{i}(2)=0;

        end % Nash alg.
    end

%% decision making - if conflict = FALSE
    for i = 1:length(agents)
        if agents(i).hold == 1 && agents(i).endflag ~= 1 % no conflicts & still active
            los = atan2(rwy(i).pos(2)-agents(i).pos(2),rwy(i).pos(1)-agents(i).pos(1));
            [dth,flag] = anglediff2(los,agents(i).hdg);
            dth=-dth*flag;
            
            % heading adjustment
            if abs(dth)>dthrecover
                if dth>0
                    dth=dthrecover;
                elseif dth<0
                    dth=-dthrecover;
                end
            end
            
            %velocity adjustment
            if agents(i).vel<norm_speed
                if norm_speed-agents(i).vel<dvrecover
                    dv=norm_speed-agents(i).vel;
                else
                    dv=dvrecover;
                end
            elseif agents(i).vel>norm_speed
                if agents(i).vel-norm_speed<dvrecover
                    dv=norm_speed-agents(i).vel;
                else
                    dv=-dvrecover;
                end
            else
                dv=0;
            end

            decisions{i}=[dth,dv,agents(i).hold];

        end
    end

%% execute single time step
    for i = 1:length(agents)
        % speed limit
        if agents(i).vel <= dvlimit*dt+minspeed && decisions{i}(2) < 0
            decisions{i}(2)=0;
        elseif agents(i).vel >= maxspeed-dvlimit*dt && decisions{i}(2)>0
            decisions{i}(2)=0;
        end
        
%         decisions{i}(1) = 0; %% only if train!!!!!!!!!!!
        if agents(i).endflag == 0
            [agents(i).pos,agents(i).vel,agents(i).hdg]=nextpos2(agents(i),decisions{i}(1),decisions{i}(2));
            if dist(agents(i).pos(1),agents(i).pos(2),rwy(i).pos(1),rwy(i).pos(2)) < buffer
                agents(i).endflag = 1;
            end
        end
    end
    
%% record
far=[];
for i = 1:length(agents)
    for j = 1:length(agents)
        if i~=j
            far(i,j)=dist(agents(i).pos(1),agents(i).pos(2),agents(j).pos(1),agents(j).pos(2));
        end
    end
end

record{1}=0;
record{2}=agents;
record{3}=risk;
record{4}=decisions;
record{5}=far;
record{6}=belief;

end