% uiopen('emer_v3.avi',1)
% wait=input('if loaded, continue');

video=pedes_free;

close all
remem=[];
for i = 1:length(video)-1
    for j = 1:anum
        for k = 1:anum
                if j ~= k
                    remem(i,j,k)=history{i,5}(j,k);
                else
            remem(i,j,k)=10000;
            end
        end
    end
end
%data processing
nearest = min(min(min(remem)));
[~,indext]=min(remem); [~,a]=min(min(remem)); [~,b]=min(min(min(remem)));
near_t = indext(1,b,a(b));

for i = 1:length(video)
imshow(video(i).cdata)
end
pause(1)
for i = 1:near_t
imshow(video(i).cdata)
end

% imshow(emer_v3(near_t).cdata)