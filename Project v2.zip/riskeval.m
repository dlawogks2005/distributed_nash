function [t,mindist,type]=riskeval(a,b)
global MSD
thres = MSD*0.001;

pos1=a.pos; v1=a.vel; h1=a.hdg;
pos2=b.pos; v2=b.vel; h2=b.hdg;

y1=pos1(2); y2=pos2(2);
x1=pos1(1); x2=pos2(1);

xdiff=x2-x1;
ydiff=y2-y1;
theta=angleis(xdiff,ydiff);
dist=sqrt(xdiff^2+ydiff^2);

%relative coordinate
x=dist*cos(pi/2-h1+theta);
y=dist*sin(pi/2-h1+theta);
h=angleis(v2*cos(h2)-v1*cos(h1),v2*sin(h2)-v1*sin(h1));
h=anglediff(h1,h)+pi/2; %����� relative heading
v=sqrt((v2*cos(h2)-v1*cos(h1))^2+(v2*sin(h2)-v1*sin(h1))^2);

%collision type estimation
if v~=0
    t=(-x*v*cos(h)-y*v*sin(h))/v^2;
    if t<0
        type=0;
        t=0;
        mindist=dist;
    elseif t>0
        y_inter=y-x*tan(h);
        mindist=sqrt((x+v*cos(h)*t)^2+(y+v*sin(h)*t)^2);
        if mindist > thres%1 %������ �浹 �Ÿ�
            if y_inter > thres%1
                type=2;
            elseif y_inter < -thres%1
                type=1;
            else
                type=4;
            end
        else
            type=3;
        end
    end
else
    t=0;
    type=0;
    mindist=dist;
end
end