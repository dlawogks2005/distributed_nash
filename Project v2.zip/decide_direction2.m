function [dth,dv,hold]=decide_direction2(a,b,eta,mindist,type,reqdist,belief)
global dvlimit dthlimit alert_t
pos1=a.pos; h1=a.hdg;
pos2=b.pos; h2=b.hdg;

y1=pos1(2); y2=pos2(2);
x1=pos1(1); x2=pos2(1);
v=a.vel;

xdiff=x2-x1;
ydiff=y2-y1;
theta=angleis(xdiff,ydiff);
theta_rel=pi/2-h1+h2;
flag=anglerel_mod(h1,theta);
flag2=anglerel_mod(h1,h2);
dist=sqrt(xdiff^2+ydiff^2);
% if eta>0 && eta< 60 && mindist<reqdist || dist<reqdist % for drones
if eta>0 && mindist<reqdist && eta < alert_t || dist < reqdist
% if  mindist<reqdist || dist<reqdist
    dth=abs((reqdist-mindist)/eta/v/(1+belief));
    dv=abs((reqdist-mindist)/cos(theta_rel)/(1+belief));
    
    if dv>dvlimit
        dv=dvlimit;
    end

    if type == 0
        dth=0;
        hold=1;
        dv=0;

    elseif type == 2
        if dth>dthlimit %max turn rate 6deg/s
            dth=dthlimit;
        end
        hold=0;
        dv=-dv;
        
    elseif type == 1
        if dth>dthlimit %max turn rate 6deg/s
            dth=dthlimit;
        end
        hold = 0;
        dth=-dth;
        dv=dv;

    else % ������ �а� �Ұ� type = 3 or type = 4
        if dth>dthlimit
            dth=dthlimit;
            hold=0;
        elseif dth<=0
            dth=0;
            hold=1;
        else
            hold=0;
        end
        dth=-dth;
        dv=-dv;
    end
    
    if type ~= 3 && type ~= 4 % ������ �а��� �Ǹ�
        if flag2 ~= 3 % ���ֺ��� �ٰ����� ���� ��
            if flag*flag2>0
                dth=dth*flag;
                dth=-dth;
            elseif flag*flag2<0
                dth=dth*flag;
            end
        elseif flag2 == 3 %�浹�� �ƴϳ� ���ֺ��� �ٰ��� ��: STATIC
            dth=abs(dth);
            dth=-dth*flag;
        end
    end

else %no conflict
    dth=0;
    hold=1;
    dv=0;
end

% post limit process
if abs(dth) < 1e-5*pi/180
    hold = 1;
end


% dv=0;
dth=dth;
dv=dv;

end