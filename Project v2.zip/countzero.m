function n=countzero(A)
n=0;
for i = 1:length(A)
    if A(i) == 0
        n=n+1;
    end
end
end