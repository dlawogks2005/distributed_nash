function [num]=no_comp(agents,rwy,MSD)
time=[];
far=ones(length(agents),length(agents))*10000;

for i = 1:length(agents)
    time(i)=dist(agents(i).pos(1),agents(i).pos(2),rwy(i).pos(1),rwy(i).pos(2))/agents(i).vel;
end

simtime=max(time);

for t = 1:simtime
    for i = 1:length(agents)
        agents(i).pos(1)=agents(i).pos(1)+agents(i).vel*cos(agents(i).hdg);
        agents(i).pos(2)=agents(i).pos(2)+agents(i).vel*sin(agents(i).hdg);
    end

    for i = 1:length(agents)
        for j = 1:length(agents)
            if i ~= j
                [eta,mindist,type]=riskeval(agents(i),agents(j));
                risk{i,j}=[eta,mindist,type];
%                 far(i,j)=dist(agents(i).pos(1),agents(i).pos(2),agents(j).pos(1),agents(j).pos(2));
            end
        end
    end

    for i = 1:length(agents)
        c=1;
        for j = 1:length(agents)
            if i~=j
                [hold]=decide_direction_nocomp(agents(i),agents(j),risk{i,j}(1),risk{i,j}(2),risk{i,j}(3),MSD);
                decision(i,c)=hold;
                c=c+1;
%                 if far(i,j)<MSD
%                     decision(i,c)=0;
%                 else
%                     decision(i,c)=1;
%                 end
%                 c=c+1;
            end
        end
        if decision(i,:) ~= 0
            history(t,i)=1;
        else
            history(t,i)=0;            
        end
    end
end
num=0;
for t = 1:length(history)
    for i = 1:length(agents)
        if history(t,i)==0
            num=num+1;
        end
    end
end
end