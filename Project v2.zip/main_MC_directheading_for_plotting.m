%% run
clear all
load('Environment')
draw_env
global dt MSD agents rwy mode
B(8) = 0.5; % dev method preference 0->dth ��ȣ 1->dv��ȣ
MSD = A(1);
plot_draw = 1;
video_record = 0;
mode = 1;

dispstat('','init');
for t=1:simtime
    [agents,output]=sim_step_execute(agents,rwy,belief,A,B,mode,anum,finished,far);
    tex=['Process : ',num2str(floor(t/simtime*100)), '%%'];
    dispstat(sprintf(tex));
    history{t,1}=t*dt;
    history{t,2}=output{2};
    history{t,3}=output{3};
    history{t,4}=output{4};
    history{t,5}=output{5};
    history{t,6}=output{6};
    far = output{5}; 
    c=0;
    for i = 1:length(agents)
        if agents(i).endflag==1
            c=c+1;
        end
    end
    
    if c==length(agents)
        simtime=t;
        break;
    end
    finished=c;
end
disp(' ')
dispstat(' ','keepprev')

%% post process
flag=zeros(1,length(agents));
for i = 1:length(agents)
    for j = 1:length(history)
        n=history{j,2}(i).endflag;
        if n==1 && flag(i)==0
            arrival(i)=j;
            flag(i)=1;
        end
        hdg_profile(i,j)=history{j,2}(i).hdg;
        vel_profile(i,j)=history{j,2}(i).vel;
        comm_profile(i,j)=history{j,4}{i}(1);
    end
end
% 
% for i = 1:length(agents)
%     if flag(i)==0
%         arrival(i)=nan;
%     end
%     temp=0;
%     if ~isnan(arrival(i))
%         for j = 1:arrival(i)
%             temp=temp+history{j,2}(i).vel;
%         end
%         tot_distance(i)=temp;
%     else
%         tot_distance(i)=nan;
%     end
% end

remem=[];
for i = floor(simtime/10):simtime-1
    for j = 1:anum
        for k = 1:anum
            if j ~= k
                remem(i-floor(simtime/10)+1,j,k)=history{i,5}(j,k);
            else
                remem(i-floor(simtime/10)+1,j,k)=nan;
            end
        end
    end
end

%data processing
nearest = min(min(min(remem)));
[~,indext]=min(remem); [~,a]=min(min(remem)); [~,b]=min(min(min(remem)));
near_t = indext(1,b,a(b));
remem_distance = remem;
% tot_flight = sum(arrival);
% density = sum(arrival)/simtime/(pi*(choke_dest_R/1000)^2)*24*365;
% 
remem=[];
for i = 1:anum
    for t = 1:simtime
%         remem(t) = abs(history{t,4}{i}(1)/dthlimit) + abs(history{t,4}{i}(2)/dvlimit);
        remem(t) = (history{t,4}{i}(1)/dthlimit)^2 + (history{t,4}{i}(2)/dvlimit)^2;
    end
%     dev_total(i)=sum(remem);
    dev_total(i)=sum(sqrt(remem));
end
remem_dev = remem;

% for i = 1:anum
% %     efficiency(i)=(dist(history{1,2}(i).pos(1),history{1,2}(i).pos(2),rwy(i).pos(1),rwy(i).pos(2))-500)/history{1,2}(i).vel/arrival(i)*100;
%     efficiency(i)=(dist(history{1,2}(i).pos(1),history{1,2}(i).pos(2),rwy(i).pos(1),rwy(i).pos(2))-500)/tot_distance(i)*100;
% end
% 
% S2=0;
% for i = 1:t
%     for j = 1:length(agents)
%         if history{i,2}(j).hold==0
% %         if history{i,6}(j,:)>MSD
%             S2=S2;
%         else
%             S2=S2+1;
%         end
%     end
% end
% if S1 == 0
%     S1 = 1;
% end
% if S2 == 0
%     S2=S1;
% end
% SF = S1/S2;
% DEP = 1/SF-1;
figure
bar(dev_total)
title('deviation total')
figure
for i = 1:anum
bar(i,min(min(remem_distance(:,i,:))))
hold on
end
plot([0 15],[MSD MSD])
title('minimum distance')
figure
for i = 1:anum
bar(i,length(remem_distance(remem_distance(:,i,:)<MSD)))
hold on
end
title('unsatisfactory length')


%% visualization
% 
% wordp=['total simulation time: ',num2str(t*dt),'sec'];
% disp(wordp)
% for i = 1:anum
%     word=['arrival time: ',num2str(arrival(i)*dt),'sec'];
%     disp(word)
% end
    
figure
for i = 1:anum
    for j = 1:anum
        if i ~= j
            if i ~= anum
                plot([1:length(remem_distance)]*dt,remem_distance(:,i,j),'k:')
            else
                plot([1:length(remem_distance)]*dt,remem_distance(:,i,j),'r')
            end
            hold on
        end
    end
end

plot([0 length(remem)*dt],[5 5],'k')
grid on
xlim([0 length(remem)*dt])
near_t*dt;
plot([near_t*dt near_t*dt],[0 nearest],'y','Linewidth',1)

for i = 1:simtime
    for j = 1:anum
        plot_history(i,j,:) = [history{i,2}(j).pos(1),history{i,2}(j).pos(2)];
    end
end

tail_l = 10;
if plot_draw == 1
    figure(1)
    for i = 1:floor(simtime*dt-tail_l)
        for j = 1:anum
            if j ~= anum
                f(i,j) = plot(plot_history(i/dt:i/dt+tail_l/dt,j,1),plot_history(i/dt:i/dt+tail_l/dt,j,2),'b.');
            else
                f(i,j) = plot(plot_history(i/dt:i/dt+tail_l/dt,j,1),plot_history(i/dt:i/dt+tail_l/dt,j,2),'r.');
            end
            g(j) = draw_circle(MSD/2,3,[plot_history(i/dt+tail_l/dt,j,1),plot_history(i/dt+tail_l/dt,j,2)]);
        end
        drawnow
        delete(f)
        delete(g)
    end 
end

% video generation part
if video_record == 1
    figure(1)
    v=VideoWriter('superman.avi');
    open(v);
    for i = 1:floor(simtime*dt)
        for j = 1:anum
            if j ~= anum
               p(i,j) = plot(history{i/dt,2}(j).pos(1),history{i/dt,2}(j).pos(2),'color',[0,0,0]+0.0,'Marker','.');
            elseif j == anum
               p(i,j) = plot(history{i/dt,2}(j).pos(1),history{i/dt,2}(j).pos(2),'r.');
            end
            g(j) = draw_circle(MSD/2,3,[history{i/dt,2}(j).pos(1),history{i/dt,2}(j).pos(2)]);
        end
        drawnow
        frame=getframe(gcf);
        writeVideo(v,frame);
        if i ~= floor(simtime*dt)
            set(g,'Visible','off')
        end
    end
    close(v);
end
% plotting part #2
% close all
% draw_env
% 
% figure(1)
% hold on
% for j = 1:anum
%     if anum~=j
%     plot(plot_history(j,1:round(near_t/20)*10,1),plot_history(j,1:round(near_t/20)*10,2),'k.')
%     else
%     plot(plot_history(j,1:round(near_t/20)*10,1),plot_history(j,1:round(near_t/20)*10,2),'r.')
%     end
%     f(j)=draw_circle(MSD/2,3,[plot_history(j,round(near_t/20)*10,1),plot_history(j,round(near_t/20)*10,2)]);
% end
% saveas(gcf,'1.png')
% input('click')
% set(f,'Visible','off')
% for j = 1:anum
%     if anum~=j
%     plot(plot_history(j,round(near_t/20)*10+1:near_t,1),plot_history(j,round(near_t/20)*10+1:near_t,2),'k.')
%     else
%     plot(plot_history(j,round(near_t/20)*10+1:near_t,1),plot_history(j,round(near_t/20)*10+1:near_t,2),'r.')
%     end
%     f2(j)=draw_circle(MSD/2,3,[plot_history(j,near_t,1),plot_history(j,near_t,2)]);
% end
% disp('nearest map')
% saveas(gcf,'2_n.png')
% input('click')
% set(f2,'Visible','off')
% for j = 1:anum
%     if anum~=j
%     plot(plot_history(j,near_t+1:round(simtime/20)*15,1),plot_history(j,near_t+1:round(simtime/20)*15,2),'k.')
%     else
%     plot(plot_history(j,near_t+1:round(simtime/20)*15,1),plot_history(j,near_t+1:round(simtime/20)*15,2),'r.')
%     end
%     f3(j)=draw_circle(MSD/2,3,[plot_history(j,round(simtime/20)*15,1),plot_history(j,round(simtime/20)*15,2)]);
% end
% saveas(gcf,'3.png')
% input('click')
% set(f3,'Visible','off')
% for j = 1:anum
%     if anum~=j
%     plot(plot_history(j,round(simtime/20)*15+1:end,1),plot_history(j,round(simtime/20)*15+1:end,2),'k.')
%     else
%     plot(plot_history(j,round(simtime/20)*15+1:end,1),plot_history(j,round(simtime/20)*15+1:end,2),'r.')
%     end
%     f4(j)=draw_circle(MSD/2,3,[plot_history(j,end,1),plot_history(j,end,2)]);
% end
% saveas(gcf,'4.png')
% 
% save('5_info.mat','nearest','near_t','arrival')

%% define function
function n=countzero(A)
n=0;
for i = 1:length(A)
    if A(i) == 0
        n=n+1;
    end
end
end

