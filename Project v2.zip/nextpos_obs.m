function [fpos,fvel,fhdg,hld]=nextpos_obs(a,dth,dv)% hold�� �ƴ� ��츸 ���.v

pos=a.pos; v=a.vel; h=a.hdg;
x=pos(1); y=pos(2);
h_next=h+dth;
v=v+dv;
endflag=a.endflag;

if abs(dth)>10^(-5)
    r=v/dth;
    xc=x-r*cos(h-pi/2);
    yc=y-r*sin(h-pi/2);
    fxpos=xc+r*cos(h_next-pi/2);
    fypos=yc+r*sin(h_next-pi/2);
else
    fxpos=x+v*cos(h);
    fypos=y+v*sin(h);
end

fpos=[fxpos,fypos];
fvel=v;
fhdg=h_next;
hld=0;
if endflag==1
    fpos=[x,y];
    fvel=v;
    fhdg=h;
    hld=1;
end

end