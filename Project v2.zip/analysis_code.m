clear all
close all
% addpath('./data_archieve');
% addpath('./data_archieve_v2');
% addpath('D:\2018_1�б�\IE801 Game Theory\Project\data_archieve_v3');
% addpath('D:\2018_1�б�\IE801 Game Theory\Project\data_archieve_v4');
% addpath('D:\2018_1�б�\IE801 Game Theory\Project\data_archieve_v5');
% addpath('D:\2018_1�б�\IE801 Game Theory\Project\data_archieve_v6');
addpath('D:\2018_1�б�\IE801 Game Theory\Project\data_archieve_v7_190724');

%% data selection
type=2; modlen=3;
% ���� nash ���� ���� �ȵ� ����. �׳� ��ճ�.
% load('vel_control_emer_data'); load('vel_control_emer_dr'); type = 2; modlen = 4;
% load('vel_control_noemer_data'); load('vel_control_noemer_dr'); type = 2; modlen = 4;
% load('dthonly_emer_data'); load('dthonly_emer_dr'); type = 2; modlen = 4;
% load('dthonly_noemer_data'); load('dthonly_noemer_dr'); type = 2; modlen = 4;
% load('drone_emer_data'); load('drone_emer_dr'); type = 2; modlen = 4;
% load('drone_noemer_data'); load('drone_noemer_dr'); type = 2; modlen = 4;
% load('belieftest_data'); load('belieftest_dr'); type = 2; modlen = 2;

% ���Ⱑ final result. spring method
% load('comparison_data'); load('comparison_dr'); type=2; modlen=2;
% load('emer_data'); load('emer_dr'); type=2; modlen=4;
% load('noemer_data'); load('noemer_dr'); type=2; modlen=4;
% load('final_emer_data'); load('final_emer_dr'); type=2; modlen=4;
% load('final_noemer_data'); load('final_noemer_dr'); type=2; modlen=4;
% load('veh_emer_data'); load('veh_emer_dr'); type=2; modlen=4;
% load('veh_noemer_data'); load('veh_noemer_dr'); type=2; modlen=4;

% �淩
% load('aero_emer_data'); load('aero_emer_dr');
% load('aero_noemer_data'); load('aero_noemer_dr');
% load('veh_emer_data'); load('veh_emer_dr');
% load('veh_noemer_data'); load('veh_noemer_dr');
% load('drone_emer_data'); load('drone_emer_dr');
% load('drone_noemer_data'); load('drone_noemer_dr');
% load('pedes_emer_data'); load('pedes_emer_dr');
% load('taxi_emer_data'); load('taxi_emer_dr');
% load('taxi_emer_data_big'); load('taxi_emer_dr_big'); %
% load('aero_emer_data_big'); load('aero_emer_dr_big'); %
% load('taxi_noemer_data'); load('taxi_noemer_dr');
% load('modified_taxi_noemer_data'); load('modified_taxi_noemer_dr');
% load('modified_taxi_emer_data'); load('modified_taxi_emer_dr');

% belief ���� ����
% load('taxi_emer_data'); load('taxi_emer_dr');
% load('aero_emer_data'); load('aero_emer_dr');
% load('free_emer_data'); load('free_emer_dr');

% load('aero_mod_data'); load('aero_mod_dr');
% load('taxi_mod_data'); load('taxi_mod_dr');

% load('aero_data'); load('aero_dr');
% load('taxi_data'); load('taxi_dr');
% load('pedes_data'); load('pedes_dr')

% load('air_saved'); load('air_DR');
% load('air_saved_neutral'); load('air_DR_neutral')
% load('taxi_saved'); load('taxi_DR');
load('taxi_saved_2'); load('taxi_DR_2')
saved_data=saved; saved_dr=reluctancy;


%% basic data extraction code
for mode=1:modlen
    for anum=1:length(saved_data)
        data=[];
        data=saved_data{mode,anum};
        if type == 0
            density(mode,anum)=mean(data(:,1));
            SF(mode,anum)=mean(data(:,4));
            SF_var(mode,anum)=var(data(:,4));
            DEP(mode,anum)=mean(data(:,5));
            DEP_var(mode,anum)=var(data(:,5));
            eff_avg(mode,anum)=mean(mean(data(:,6:5+anum*2)));
            var_avg(mode,anum)=mean(var(data(:,6:5+anum*2)));
            mindist(mode,anum)=mean(mean(data(:,3)));
            mindist_var(mode,anum)=mean(var(data(:,3)));
            dev_total(mode,anum)=mean(mean(data(:,6+anum*2:end)));
        elseif type == 1 || type == 2
            density(mode,anum)=mean(data(:,1));
            density_var(mode,anum)=std(data(:,1));
            SF(mode,anum)=mean(data(:,4));
            SF_var(mode,anum)=var(data(:,4));
            DEP(mode,anum)=mean(data(:,5));
            DEP_var(mode,anum)=std(data(:,5));
            eff_avg(mode,anum) = mean(mean(data(:,6:5+anum*2-1)));
            var_avg(mode,anum)=mean(var(data(:,6:5+anum*2)));
            eff_emer(mode,anum) = mean(mean(data(:,5+anum*2)));
            mindist(mode,anum)=mean(mean(data(:,3)));
            mindist_var(mode,anum)=mean(var(data(:,3)));
            dev_total_avg(mode,anum)=mean(mean(data(:,6+anum*2:end-1)));
            dev_total_emer(mode,anum)=mean(data(:,end));
            if type == 2
                yieldness(mode,anum) = dev_total_avg(mode,anum)/dev_total_emer(mode,anum);
            else
                yieldness(mode,anum) = (100-eff_avg(mode,anum))/(100-eff_emer(mode,anum));
            end
        end
    end
end

%% priority management testing (for noemer case)

% clf(figure(9))
mode = 2; anum = 1;
eff=[];
% if type == 0    
    for i = 1:length(saved_data{mode,anum})
        if type == 2
            A=normalize(saved_data{mode,anum}(i,6+anum*2:end),'norm'); % �� efficiency ����
        else
            A=normalize(100-saved_data{mode,anum}(i,6:5+anum*2),'norm'); % ���� efficiency ����
        end        
        eff=horzcat(eff,A);
    end
    eff=eff';
    rel=[];
    for i = 1:length(saved_data{mode,anum})
        enum=anum*2;
        A=normalize(saved_dr{mode,anum}(i,1:enum),'norm');
        rel=horzcat(rel,A);
    end
    rel=rel';
    
% figure(9) % ����ǥ
% plot(rel,eff,'x')
% p=lsline;
% set(lsline,'color','r')
% title('urgency - efficiency distribution','fontsize',15); xlabel('normalized urgency','fontsize',14); ylabel('normalized efficiency','fontsize',14);
% xlim([-0.05 1.05])
% ylim([-0.05 1.05])
% grid on
% hold on
% plot([0,1],[1,1],'k')
% plot([0,1],[0,0],'k')
% plot([1,1],[0,1],'k')
% plot([0,0],[1,0],'k')
% (p.YData(2)-p.YData(1))/(p.XData(2)-p.XData(1));
% end

% if type == 0
%     eff=[];
%     rel=[];
%     for mode = 1:modlen
%         for anum = 1:length(saved_data)
%             corr_temp=[];
%             for i = 1:length(saved_data{mode,anum})
%                 enum=anum*2;
%                 if type ==2
%                     eff=normalize(saved_data{mode,anum}(i,6+anum*2:end),'norm');
%                 else
%                     eff=normalize(100-saved_data{mode,anum}(i,6:5+anum*2),'norm');
%                 end
%                 rel=normalize(saved_dr{mode,anum}(i,1:enum),'norm',1);
%                 out=corrcoef(rel,eff);
%                 corr_temp(i)=out(1,2);
%             end
% %             corr_eff(mode,anum)=eff; corr_rel(mode,anum)=rel;
%             corr_mean(mode,anum)=mean(corr_temp);
%             corr_mean2(mode,anum)=mean(corr_temp.^2);
%             corr_var(mode,anum)=var(corr_temp);
%             corr_var2(mode,anum)=var(corr_temp.^2);
%             corr_p(mode,anum)=anova1([corr_temp;zeros(1,length(corr_temp))]',[],'off');
%         end
%     end
   

% figure(11) % r square
% hold on
% for i = 1:modlen
% errorbar(density(i,2:end),corr_mean2(i,2:end),corr_var2(i,2:end))
% end
% % plot([1 8.3],[0 0],'k:')
% legend('Myopic','Naive Nash','Urgency considered Nash')
% title('r-square','fontsize',15); xlabel('traffic density [fhr/km^2/yr]','fontsize',14); ylabel('coefficient','fontsize',14);
% grid on
% saveas(gcf,'rsq.png')

%% basic data plot code

    figure(12) %eff to d
    hold on
    for mode = 1:modlen
        plot(density(mode,:),eff_avg(mode,:),'*--')
%         errorbar(density(mode,:),eff_avg(mode,:),sqrt(var_avg(mode,:)))
    end
    legend('Myopic','Naive Nash','Urgency considered Nash')
%     anova1([eff_avg(1,:);eff_avg(3,:)]'); % Nash effectively worse
    title('TDE','fontsize',15); xlabel('traffic density [fhr/km^2/yr]','fontsize',14); ylabel('accumulated acceleration','fontsize',14);
    grid on
%     saveas(gcf,'acctot.png')

    figure(13) %DEP to d
    hold on
    for mode = 1:modlen
%         errorbar(density(mode,:),SF(mode,:),sqrt(SF_var(mode,:)))
%         errorbar(density(mode,:),DEP(mode,:),sqrt(DEP_var(mode,:)))
        plot(density(mode,:),DEP(mode,:),'*--')
    end
%     lsline
    legend({'Myopic','Naive Nash','Urgency considered Nash'},'Location','east')
    title('Domino Effect Parameter','fontsize',15); xlabel('traffic density [fhr/km^2/yr]','fontsize',14); ylabel('DEP','fontsize',14);
    grid on
%     saveas(gcf,'sf.png')
    
    figure(14) % yield to d
    hold on
    for mode = 1:modlen
        plot(density(mode,:),yieldness(mode,:),'*--')
%         plot([1:anum]*2,yieldness(mode,:),'*--')
%         breakplot(density(mode,:),yieldness(mode,:),10,90,'Line')
    end
%     lsline
    legend('Myopic','Naive Nash','Urgency considered Nash')
    grid on
%     anova1([yieldness(1,:);yieldness(3,:)]');
    title('TDE ratio','fontsize',15); xlabel('traffic density [fhr/km^2/yr]','fontsize',14); ylabel('ratio','fontsize',14);
%     saveas(gcf,'yield.png')
    
figure(15)
    hold on
    for mode = 1:modlen
        plot(density(mode,:),mindist(mode,:)/1000,'*--')
%         plot([1:anum]*2,mindist(mode,:)/1000,'*--')
%         errorbar(density(mode,:), mindist(mode,:)/1000, sqrt(mindist_var(mode,:))/1000)
    end
    grid on
    legend('Myopic','Naive Nash','Urgency considered Nash')
    title('Minimum distance observed','fontsize',15); xlabel('traffic density [fhr/km^2/yr]','fontsize',14); ylabel('distance [km]','fontsize',14);
%     saveas(gcf,'mindist.png')

figure(16)
    hold on
    for mode = 1:modlen
        plot([2:16],density(mode,:),'*--')
%         errorbar([2:16],density(mode,:),sqrt(density_var(mode,:)))
    end
    grid on
    legend({'Myopic','Naive Nash','Urgency considered Nash'},'Location','northwest')
    title('Traffic density','fontsize',15); xlabel('number of agents','fontsize',14); ylabel('space occupation density [fhr/km^2/yr]','fontsize',14);
%     saveas(gcf,'density.png')
