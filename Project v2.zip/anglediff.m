function t = anglediff(a,b) %�� + �� -
if b-a+pi < 0
    t = b-a+2*pi;
elseif b-a-pi > 0
    t = b-a-2*pi;
else
    t = b-a;
end
end