function [fpos,fvel,fhdg]=nextpos2(a,dth,dv)% hold�� �ƴ� ��츸 ���.v
global dt

pos=a.pos; v=a.vel; h=a.hdg;
x=pos(1); y=pos(2);
h_next=h+dth*dt;
v=v+dv*dt;
endflag=a.endflag;

if abs(dth)>10^(-5)
    r=v/dth;
    xc=x-r*cos(h-pi/2);
    yc=y-r*sin(h-pi/2);
    fxpos=xc+r*cos(h_next-pi/2);
    fypos=yc+r*sin(h_next-pi/2);
else
    fxpos=x+v*cos(h)*dt;
    fypos=y+v*sin(h)*dt;
end

fpos=[fxpos,fypos];
fvel=v;
fhdg=h_next;

if endflag==1
    fpos=[x,y];
    fvel=0.0001;
    fhdg=0;
end

end