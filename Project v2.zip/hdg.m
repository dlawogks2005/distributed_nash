function theta=hdg(heading)
theta=mod(heading,360);
theta=(theta-90)/180*pi;
theta=2*pi-theta;
theta=mod(theta,2*pi);
end