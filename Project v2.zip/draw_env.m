clf
f=figure(1);
set(f,'position',[2000,100,800,800])
hold on
grid on
title('trajectory profile','fontsize',14)
xlabel('x position[m]','fontsize',14)
ylabel('y position[m]','fontsize',14)
hold on


for i =  1:s_num
    plot(s_pos(i,1),s_pos(i,2),'rx')
end
for i = 1:s_num
    for j = 1:s_num
        plot([s_pos(i,1),s_pos(j,1)],[s_pos(i,2),s_pos(j,2)],'k:')
    end
end
xlim([min(s_pos(:,1))-MSD*2,max(s_pos(:,1))+MSD*2])
ylim([min(s_pos(:,2)-MSD*2),max(s_pos(:,2))+MSD*2])
drawnow 

% xlim([-choke_dest_R choke_dest_R])
% ylim([-choke_dest_R choke_dest_R])
