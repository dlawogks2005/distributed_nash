% clear all
% close all
clear history agents belief choke_a arrival 
clear density tot_flight efficiency nearest
addpath('./trajectory');
% mode=2;
%% sim setting
global dt step
simtime=1000; %simulation length (not time)
dt=1; step=5;
time=0:dt:simtime*dt;

% anum=20; %number of agents
MSD = 3000;
Rlim = 60*10^3;
choke_dest_R = 70*10^3; %4488 nm^2 -> anum 4~10�̸� density: 4.5~22 / 100nm^2e

risk=[];
rwy=[];
decisions=[];
belief_diff=zeros(anum,anum); %belief difference
far=ones(anum,anum)*1000000;
compete=ones(1,anum)*1000000;
check = 0;

%% creating agents / destination / belief
while check == 0
    for i =  1:anum
        choke_a(i) = rand(1)*2*pi;
%         choke_R = Rlim*3/5+rand(1)*Rlim*2/5;
        choke_R = Rlim-MSD/2+rand(1)*MSD; %�浹�� �� �Ͼ���� ������.
        want = rand(1)*1000;
        agents(i).pos=[choke_R*cos(choke_a(i)),choke_R*sin(choke_a(i))];  agents(i).hdg=mod(choke_a(i)+pi,2*pi);  ...
%         agents(i).pos=[Rlim*cos(choke_a(i)),Rlim*sin(choke_a(i)   )];  agents(i).hdg=mod(choke_a(i)+pi,2*pi);  ...
            agents(i).vel=200;  agents(i).req=1000+want; ...
            agents(i).hold=0; agents(i).radius=agents(i).vel*60/pi; agents(i).endflag=0;
    end
    
    % belief hold
    for i = 1:anum
        agents(i).req=1000+(i-1)*1000/(anum-1);
    end
    
    remem=[];
    for j = 1:anum
        for k = 1:anum
            if j ~= k
                remem(j,k)=dist(agents(j).pos(1),agents(j).pos(2),agents(k).pos(1),agents(k).pos(2));
            else
                remem(j,k)=10^6;
            end
        end
    end

    if min(min(remem))<MSD
        check = 0;
    else
        check = 1;
    end
    
end
% agents(anum).req=100;

for i = 1:anum
    DR(i)=agents(i).req;
end %DR generation

% agents(1).req=0;
% agents(1).pos=[0,0];
% agents(1).hdg=0;
% agents(1).vel=0;
% agents(1).hold=0;
% agents(1).endflag=1;


%% runway generation
% runway generation - choke
% for i = 1:anum
%     rwy(i).pos=[choke_dest_R*cos(choke_a(i)+pi),choke_dest_R*sin(choke_a(i)+pi)]; rwy(i).hdg=agents(i).hdg;
% end

% runway generation - tot. random
% for i = 1:anum
%     choke_a(i) = rand(1)*2*pi;
%     rwy(i).pos=[choke_dest_R*cos(choke_a(i)),choke_dest_R*sin(choke_a(i))]; 
%     vec=rwy(i).pos-agents(i).pos;
%     vec_angle=atan2(vec(2),vec(1));
%     rwy(i).hdg=vec_angle;
%     agents(i).hdg=vec_angle;
% end

% runway generation - choke with angle randomness
for i = 1:anum
    const=rand(1)*asin(MSD/2/Rlim)*2-asin(MSD/2/Rlim);
    rwy(i).pos=[choke_dest_R*cos(choke_a(i)+pi+const),choke_dest_R*sin(choke_a(i)+pi+const)];
    vec=rwy(i).pos-agents(i).pos;
    vec_angle=atan2(vec(2),vec(1));
    rwy(i).hdg=vec_angle;
    agents(i).hdg=vec_angle;
end

% runway generation - airport landing
% for i = 1:anum
%     rwy(i).pos=[10000,5000]; rwy(i).hdg=pi/2;
% end

for i = 1:anum
    for j = 1:anum
        belief(i,j)=agents(j).req/agents(i).req;
    end
end % belief construction
origin=belief;

% clf
% f=figure(1);
% set(f,'position',[2000,100,800,800])
% hold on
% grid on
% title('trajectory profile','fontsize',14)
% xlabel('x position[m]','fontsize',14)
% ylabel('y position[m]','fontsize',14)
% hold on
% draw_circle(choke_dest_R,1)
% draw_circle(Rlim,2)
% draw_circle(Rlim*3/5,2)
% for i =  1:anum
%     plot([agents(i).pos(1),rwy(i).pos(1)],[agents(i).pos(2),rwy(i).pos(2)],':')
%     plot(rwy(i).pos(1),rwy(i).pos(2),'x')
%     plot(agents(i).pos(1),agents(i).pos(2),'o')
% end
% xlim([-choke_dest_R choke_dest_R])
% ylim([-choke_dest_R choke_dest_R])
% drawnow

% belief=ones(anum,anum);
% belief=ones(anum,anum)/100000;
if mode == 1
    belief=ones(anum,anum)/1000000;
end
request=0;
%% run
S1=no_comp(agents,rwy,MSD);

for i = 1:length(agents)
    if agents(i).hold == 0
        [path, length_All, length_LR_SEG, type] = dubins_curve_v2([agents(i).pos,agents(i).hdg], ...
            [rwy(i).pos,rwy(i).hdg], agents(i).radius, step, 0, 0, request); %radius, step, ~, ~
        agents(i).traj.path=path;
        agents(i).traj.len=length_All;
        agents(i).traj.LRlen=length_LR_SEG;
        agents(i).traj.type=type;
    end
end %initial path generation
c=0; %finnum

for t=1:simtime
    decision=0;

%% eval others (What are they doing?) - risk eval
    for i = 1:length(agents)
        for j = 1:length(agents)
            if i~=j && agents(j).endflag ~= 1
                [eta,mindist,type]=riskeval(agents(i),agents(j)); %type => front? back? tie?
                risk{i,j}=[eta,mindist,type];
            end
        end
    end
    
%% decision making - risk
if mode == 1
    for i = 1:length(agents)
%     ���� ��� - ����� �� ����, eta �������
    temp=ones(1,anum)*10^20;
    n=1;
    for j = 1:anum
        if i~=j
            temp(n)=risk{i,j}(1);
%             temp(n)=far(i,j);
        end
        n=n+1;
    end
    [~,num]=min(temp);
    [dth,dv,go]=decide_direction(agents(i),agents(num),risk{i,num}(1),risk{i,num}(2),risk{i,num}(3),MSD,belief(i,num)); 

    if dth==0 && dv==0
        temp=ones(1,anum)*10^20;
        n=1;
        for j = 1:anum
            if i~=j
                temp(n)=far(i,j);
%                 temp(n)=risk{i,j}(1);
            end
            n=n+1;
        end
        [~,num]=min(temp);
        [dth,dv,go]=decide_direction(agents(i),agents(num),risk{i,num}(1),risk{i,num}(2),risk{i,num}(3),MSD,belief(i,num));
        agents(i).hold=go;
    end
    
    decisions{i}=[dth,dv,go];
    agents(i).hold=go;
    end %eta
elseif mode == 2 || mode == 3
    for i = 1:length(agents)
    temp=[];
    norm=[];
    n=1;
    for j = 1:length(agents)
        if j ~= i
            num=j;
            [dth,dv,go]=decide_direction(agents(i),agents(num),risk{i,num}(1),risk{i,num}(2),risk{i,num}(3),MSD,belief(i,num));
            temp(n,:)=[dth,dv,go];
            n=n+1;
        end
    end

%     multi conflict case
    zeronum=countzero(temp(:,1));
    if zeronum == anum-1
        dth=0; dv=0;
    else
        norm=ones(1,anum-1)/(anum-1-zeronum);
        dth=norm*temp(:,1);
        dv=norm*temp(:,2);
    end
    
    if temp(:,3)~=0 %��� 0�� �ƴϾ�� �����.
        go=go;
    else            %�ϳ��� 0�̸� go�� 0
        go=0;
    end
    
    decisions{i}=[dth,0,go];
    agents(i).hold=go;
    
%     ��ֹ��� ���⸦ ����϶�
    if agents(i).endflag == 1
        agents(i).hold = 0;
    end

    end %average
end

%% generate path (Your intention is?)
    for i = 1:length(agents)
        if agents(i).hold == 1 && agents(i).endflag ~= 1
            [path, length_All, length_LR_SEG, type] = dubins_curve_v2([agents(i).pos,agents(i).hdg], ...
                [rwy(i).pos,rwy(i).hdg], agents(i).radius, step, 0, 0, request); %radius, step, ~, ~
            agents(i).traj.path=path;
            agents(i).traj.len=length_All;
            agents(i).traj.LRlen=length_LR_SEG;
            agents(i).traj.type=type;
        end
    end

%% ������ (Go!) - pos,vel,hdg update
    for i = 1:length(agents)
        if agents(i).hold~=0
            [agents(i).pos,agents(i).vel,agents(i).hdg,agents(i).hold,agents(i).endflag]=proceed(agents(i),decisions{i}(2));
        elseif agents(i).hold==0
            [agents(i).pos,agents(i).vel,agents(i).hdg,agents(i).hold]=nextpos(agents(i),decisions{i}(1),decisions{i}(2));
        end
        
        if dist(agents(i).pos(1),agents(i).pos(2),rwy(i).pos(1),rwy(i).pos(2)) < 500 && ...
            abs(agents(i).hdg-rwy(i).hdg)<10*pi/180
            agents(i).endflag = 1;
        end
    end

%% belief update
    alpha = 1; %alpha�� 1�̸� �ﰢ �н�/ <1�̸� ������ �н�
    if mode == 3 %do update
        for i = 1:anum
            for j = 1:anum
                if i ~= j && decisions{i}(1) ~= 0
                    obs=decisions{j}(1);
                    mine=decisions{i}(1);
                    if belief(i,j) ~= -1
                        temp = obs/mine/(1+belief(i,j));
                    else
                        temp = 10^5;
                    end
                    if temp ~= 1
                        actual=temp/(1-temp);
                    else
                        actual=10^5;
                    end
                    belief_diff=actual-belief(i,j); %������ ��밡 �� ������. ����� ��밡 �� ������.
                    
                    if belief(i,j)+belief_diff*alpha <= origin(i,j) && abs(obs) <= 6*pi/180
                        belief(i,j)=belief(i,j)+belief_diff*alpha;
                    elseif abs(obs) == 6*pi/180
                        belief(i,j)=belief(i,j);
                    else
                        belief(i,j)=origin(i,j);
                    end
                end
            end
        end
    end
    
%% record
far=[];
for i = 1:length(agents)
    c=1;
    for j = 1:length(agents)
        if i~=j
            far_temp(i,c)=dist(agents(i).pos(1),agents(i).pos(2),agents(j).pos(1),agents(j).pos(2));
            far(i,j)=dist(agents(i).pos(1),agents(i).pos(2),agents(j).pos(1),agents(j).pos(2));
            c=c+1;
        end
    end
end
history{t,1}=t*dt;
history{t,2}=agents;
history{t,3}=risk;
history{t,4}=decisions;
history{t,5}=far;
history{t,6}=belief;

%% termination
c=0;
for i = 1:length(agents)
    if agents(i).endflag==1
        c=c+1;
    end
end
if c==length(agents)
    simtime=t;
    break;
end

% wordp=[num2str(t),'simsec passed'];
% disp(wordp)

end

%% post process
flag=zeros(1,length(agents));
for i = 1:length(agents)
    for j = 1:length(history)
        n=history{j,2}(i).endflag;
        if n==1 && flag(i)==0
            arrival(i)=j;
            flag(i)=1;
        end
        hdg_profile(i,j)=history{j,2}(i).hdg;
        vel_profile(i,j)=history{j,2}(i).vel;
        comm_profile(i,j)=history{j,4}{i}(1);
    end
end

for i = 1:length(agents)
    if flag(i)==0
        arrival(i)=nan;
    end
end

%data processing
nearest = min(min(min(remem)));
tot_flight = sum(arrival);
density = sum(arrival)/simtime/(pi*(choke_dest_R/1000)^2)*24*365;
for i = 1:anum
    efficiency(i)=(dist(history{1,2}(i).pos(1),history{1,2}(i).pos(2),rwy(i).pos(1),rwy(i).pos(2))-500)/history{1,2}(i).vel/arrival(i)*100;
end

S2=0;
for i = 1:t
    for j = 1:length(agents)
        if history{i,2}(j).hold==0
%         if history{i,6}(j,:)>MSD
            S2=S2;
        else
            S2=S2+1;
        end
    end
end
if S1 == 0
    S1 = 1;
end
if S2 == 0
    S2=S1;
end
SF = S1/S2;
DEP = 1/SF-1;

%% visualization

% wordp=['total simulation time: ',num2str(t),'sec'];
% disp(wordp)
% for i = 1:anum
%     word=['arrival time: ',num2str(arrival(i)),'sec'];
%     disp(word)
% end
    
% figure(1)
% f=figure(1);
% set(f,'position',[2000,100,800,800])
% hold on
% grid on
% title('trajectory profile','fontsize',14)
% xlabel('x position[m]','fontsize',14)
% ylabel('y position[m]','fontsize',14)
% xlim([-choke_dest_R choke_dest_R])
% ylim([-choke_dest_R choke_dest_R])
% draw_circle(choke_dest_R,1)
% draw_circle(Rlim,2)
% 
% % text(rwy.pos(1),rwy.pos(2),txt1,'HorizontalAlignment','right')
% 
% for i = 1:simtime
%     for j = 1:anum
%         if j ~= anum
%             plot(history{i,2}(j).pos(1),history{i,2}(j).pos(2),'b.')
%         else
%             plot(history{i,2}(j).pos(1),history{i,2}(j).pos(2),'r.')
%         end
%         p(j)=plot(history{i,2}(j).traj.path(:,1),history{i,2}(j).traj.path(:,2),'b:');
%     end
%     figure(1)
%     set(p,'Visible','off')
% end

% remem=[];
% for i = 1:min(arrival)-1
%     for j = 1:anum
%         for k = 1:anum
%             if j ~= k
%                 remem(i,j,k)=history{i,5}(j,k);
%             else
%                 remem(i,j,k)=10000;
%             end
%         end
%     end
% end



% A=['minimum distance: ',num2str(nearest),'m'];
% B=['total flight hour: ',num2str(tot_flight),'s'];
% C=['density (Fhr/km^2): ',num2str(density)];
% disp(A)
% disp(B)
% disp(C)

%% define function
function draw_circle(r,f)
t=0:pi/180:2*pi-pi/180;
if f == 1
    plot(r*cos(t),r*sin(t),'b.')
else
    plot(r*cos(t),r*sin(t),'r:')
end
end

function n=countzero(A)
n=0;
for i = 1:length(A)
    if A(i) == 0
        n=n+1;
    end
end
end

