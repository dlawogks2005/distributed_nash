clear all
close all
addpath('./trajectory');
mode=3;
%% sim setting

ap=1; % agility parameter

% % [MSD max_r min_r buffer] [nomv minv maxv maxacc nomacc maxdth nomdth w]

% A=[3000 30 35 500]; B=[210,180,250,3,1,6*pi/180,3*pi/180,0.8]; % for aero
% A=[3000 30 35 400]; B=[210,180,250,3,1,6*pi/180,3*pi/180,0.5]; % for aero
% A=[400 2 2.3 100];  B=[36 0 44.2 4 2 20*pi/180 5*pi/180 0.5]; %for quadrotor designed air taxi
A=[5 0.05 0.055 5]; B=[1,0,2,1,0.5,pi/2,pi/8,0.5]; % for pedestrians
% A=[5 0.05 0.055 5]; B=[1,0,4,1,0.5,pi/2,pi/4,0.5]; % for superman
% A=[300 2 2.2 50]; B=[20,0,40,3,2,0.01,0.01,0.5]; % for train

global dt dvlimit dthlimit weight buffer
simtime=15000; %simulation length (not time)
dt=0.1; 
time=0:dt:simtime*dt;

anum=10; %number of agents
MSD = A(1);
Rlim = A(2)*10^3;
choke_dest_R = A(3)*10^3; %4488 nm^2 -> anum 4~10�̸� density: 4.5~22 / 100nm^2
norm_speed=B(1); minspeed=B(2); maxspeed=B(3);

risk=[];
rwy=[];
decisions=[];
far=ones(anum,anum)*1000000;
compete=ones(1,anum)*1000000;
check = 0;
finished=0; %��ǥ���� ���� agent ��

dvlimit=B(4); dvrecover=B(5);  dthlimit=B(6); dthrecover=B(7); weight=B(8);
buffer = A(4);

%% creating agents / destination / belief
while check == 0
    for i =  1:anum
        choke_a(i) = rand(1)*2*pi;
%         choke_a(i) = 2*pi/anum*i;
% %         choke_R = Rlim*0+rand(1)*Rlim;
%         choke_R = Rlim;
        choke_R = Rlim-MSD/2+rand(1)*MSD; %�浹�� �� �Ͼ���� ������.
        want = rand(1)*100;
%         want = 0;
        agents(i).pos=[choke_R*cos(choke_a(i)),choke_R*sin(choke_a(i))];  agents(i).hdg=mod(choke_a(i),2*pi);  ...
%         agents(i).pos=[Rlim*cos(choke_a(i)),Rlim*sin(choke_a(i)   )];  agents(i).hdg=mod(choke_a(i)+pi,2*pi);  ...
            agents(i).vel=norm_speed;  agents(i).req=1000+want; ...
            agents(i).hold=1; agents(i).endflag=0;
    end
    agents_initial=agents;
    % belief hold
%     for i = 1:anum
%         agents(i).req=1000+(i-1)*1000/(anum-1);
%     end
    
    remem=[];
    for j = 1:anum
        for k = 1:anum
            if j ~= k
                remem(j,k)=dist(agents(j).pos(1),agents(j).pos(2),agents(k).pos(1),agents(k).pos(2));
            else
                remem(j,k)=10^6;
            end
        end
    end

    if min(min(remem))<MSD*1.5
        check = 0;
    else
        check = 1;
    end
    
end
% agents(anum).req=10;



%% runway generation
% runway generation - choke
% for i = 1:anum
%     rwy(i).pos=[choke_dest_R*cos(choke_a(i)+pi),choke_dest_R*sin(choke_a(i)+pi)]; rwy(i).hdg=agents(i).hdg;
% end

% runway generation - tot. random
% for i = 1:anum
%     choke_a(i) = rand(1)*2*pi;
%     rwy(i).pos=[choke_dest_R*cos(choke_a(i)),choke_dest_R*sin(choke_a(i))]; 
%     vec=rwy(i).pos-agents(i).pos;
%     vec_angle=atan2(vec(2),vec(1));
%     rwy(i).hdg=vec_angle;
%     agents(i).hdg=vec_angle;
% end

% runway generation - choke with angle randomness
for i = 1:anum
    const=rand(1)*asin(MSD/2/Rlim)*2-asin(MSD/2/Rlim); const=const*0.5;
%     const = rand(1)*pi-pi/2;
    rwy(i).pos=[choke_dest_R*cos(choke_a(i)+pi+const),choke_dest_R*sin(choke_a(i)+pi+const)];
    vec=rwy(i).pos-agents(i).pos;
    vec_angle=atan2(vec(2),vec(1));
    rwy(i).hdg=vec_angle;
    agents(i).hdg=vec_angle;
end


for i = 1:anum
    for j = 1:anum
        belief(i,j)=agents(j).req/agents(i).req;
    end
end % belief construction
origin=belief;

if mode == 1 || mode == 2
    belief=ones(anum,anum);
end
belief_reverse=belief';
request=0;
S1=no_comp(agents,rwy,MSD);
c=0; %finnum

clear f
save('Environment')
