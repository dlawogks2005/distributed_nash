clear all

tot_agent=10;
output=[];
dispstat('','init');

for anum = 2:tot_agent
%     anum=anum*2;
    temp=[];
    for trial = 1:1000
        conflict_prob;
        if isnan(conflict_total) == 0
            temp=vertcat(temp,conflict_total);
        end
        tex=[' anum: ',num2str(anum),' processed by: ',num2str(trial/1000*100),'%%'];
        dispstat(sprintf(tex));
    end
    dispstat(' ','keepprev')
    output{anum}=mean(temp,1);
end

%% plotting result
output=output';
figure(1)
xlim([1 10])
grid on
title('Num of simultaneous conflicts','fontsize',15)
ylabel('Probability [%]','fontsize',14)
xlabel('Number of agents','fontsize',14)
for j = 1:10
plot(output{j},'--*')
pause(0.5)
hold on
end
